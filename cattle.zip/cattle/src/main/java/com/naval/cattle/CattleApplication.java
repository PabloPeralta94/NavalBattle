package com.naval.cattle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CattleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CattleApplication.class, args);
	}

}
